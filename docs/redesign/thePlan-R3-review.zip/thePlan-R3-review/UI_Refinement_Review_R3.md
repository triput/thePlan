<!--
==============================================================================
  File: docs/redesign/UI_Refinement_Review_R3.md
  Description: Refinement pass R3 — Midnight Workbench with a shared support panel.
  Component: Design
  Version: 1.0 (Review)
  Created: 2026-10-10
  Last Update: 2026-10-10
==============================================================================
-->

# thePlan UI refinement R3 — Midnight Workbench

This is one refined direction for review, produced from `UI_Refinement_Brief.md`. It is not an implementation specification. No production code, commits or deployments were made, and no further directions were explored.

## 1. Rationale

Midnight Workbench stays the visual foundation: cool dark surfaces, a restrained hierarchy, a visible scope tree, and grouped placement details. From Sonnet's Ledger I took one idea: a **single support panel**. Unscheduled work, the open preview and the calendar key share one panel. Task details replace the panel's content rather than opening a second inspector, and collapsing the panel returns its width to the calendar.

Everything else was decided by space and attention. I didn't add Ledger's hatching or stripes, Studio's swimlanes, per-day load totals, activity history or per-change undo. Each of these would compete with the week itself, and several would imply capabilities that may not exist.

## 2. What changed from Midnight Workbench (round 2)

| Area | Round 2 | R3 |
| --- | --- | --- |
| Support area | Docked inspector plus a separate unplaced list, legend and stats | One 360 px panel with **Unscheduled · Preview · Key** tabs. Task details replace the panel. It collapses to a 48 px strip with vertical labels and counts. |
| Calendar density | 11 px metadata, hatched windows, everything visible at once | All content text is 13 px or larger. Block text is laid out by block height, so lines are never cut. Time Map bands are a quiet tint with a dotted edge. Exclusions are a labelled darker band. |
| Item states | Pinned or movable, signalled mostly by fill | External, pinned, movable, proposed and moving-away blocks each differ by icon *and* border style. Fill colour is a third cue, never the only one. |
| Navigation | Expanded sidebar only | Expanded tree (220 px) or a 56 px icon rail. The rail has tooltips and flyouts for Epics, Projects and Saved views. Its toggle is labelled, with the key `[`. |
| Schedule controls | Preview, Update and Clear in one banner | A schedule bar with five explicit states. While a preview is open, Update schedule is replaced by **Apply preview… / Discard preview**. |
| Copy | "Must not miss", Undo per move, design notes inside the app | Accurate constraint language, a "Can't fit before deadline" outcome, and no undo or history UI. Annotations live in this document and on canvas notes. |

## 3. Screens

All screens use the same content: the week of Oct 12–18 with the Kubernetes Essentials coursework. Exports are at actual pixel size (1×) unless noted.

| Brief item | Export | Canvas artboard |
| --- | --- | --- |
| 1 · Busy week 1440×900, panel open | `01a` (item selected, popover open), `01b` (same, nothing selected) | R-Week-Dock |
| 1 · Busy week 1440×900, panel collapsed | `01c` (same content), `01d` (key open on demand) | R-Week-Collapsed |
| Browser zoom | `01e`: the collapsed layout at 125% zoom (1152×720 CSS px rendered at 1.25 device scale) | R-Week-Collapsed |
| 2 · Calendar 1366×768, rail, task details in panel | `02a`; `02b` shows the same viewport with the Preview tab | R-1366-Detail |
| 2 · Reaching projects from the rail | `02c` | R-Rail |
| 3 · Populated workflow board | `03` | R-Board |
| 4 · Task detail | `04a` full-length panel (360 px wide), `04b` compact state sheet | R-Detail-Panel, R-States |
| 5 · Hierarchical coursework list | `05` (1440), `05b` (1366) | R-List |
| Specification | `06` | R-Spec |

The canvas holds editable source on the page "R3 · Midnight Workbench refinement". The calendar artboards have Tweaks for panel state (preview / collapsed / detail), navigation (expanded / rail), compact hour height, and key and popover visibility.

## 4. Interaction notes

### 4.1 Support panel

- **Tabs.** Unscheduled (count), Preview (count; shown only while a preview exists) and Key. The panel remembers the last tab per view.
- **Collapse.** Use the panel icon or `\`. The collapsed strip keeps every tab reachable: vertical labels with counts, and the active tab is highlighted. Nothing essential lives only in the panel. Apply and Discard sit in the schedule bar, so collapsing hides no action.
- **Column width, measured in the renders:**

  | Layout | Day column |
  | --- | --- |
  | 1440, panel open | 115 px |
  | 1440, panel collapsed | 160 px |
  | 1366, rail with task details | 128 px |
  | 1440 at 125% zoom, panel collapsed | 119 px |

- **Task details replace the panel's content.** Selecting a block shows a small popover: full title, time, dates, placement mode, Time Map, and Open details / Pin this time / Unschedule. Pressing `↵`, choosing Open details, or picking a change in the Preview list replaces the panel content with Task details. The header breadcrumb **‹ Preview / Task details** names where Back goes.
- **The preview context is preserved.** The preview stays open, and its dashed blocks stay on the grid while details are shown. Back, Esc or × returns to the Preview tab and its scroll position.
- **Unsaved edits.** Back, Esc, ×, or selecting another task shows an inline prompt at the top of the panel: **Save and open / Discard and open / Keep editing** (state sheet, row 2). It is never a modal, and nothing is discarded silently.
- **Edits after a preview.** Saving a change that the open preview depended on marks the preview **out of date**. Apply is replaced by **Re-run preview** (state sheet, row 1). The preview is never silently recomputed or applied.

### 4.2 Navigation

- **Expanded (220 px):** Calendar, Today, Upcoming, Inbox, Work, then Epics with their projects, standalone Projects, and Saved views. Labels leave the tree; they are filters (round-2 decision).
- **Rail (56 px):** icons only, with no clipped labels. Every item has an accessible name and shows a tooltip on hover or focus. Epics, Projects and Saved views open flyouts with a filter field. The flyout separates projects in epics from standalone projects, so epic membership is never required. "Show full navigation `[`" sits at the bottom of each flyout, and the rail's first button expands it.
- **Proposed rule:** below a 1200 px viewport the app starts with the rail. Both navigation and panel state persist per device.

### 4.3 Schedule actions

- **Preview changes** computes proposals and changes nothing.
- **Update schedule…** confirms, then evaluates and applies in one step.
- While a preview is open, the bar shows **Apply preview… / Discard preview** instead. Apply applies everything together; there is no selective apply.
- The bar has five states: Not evaluated, Current, Out of date, Preview open, Preview out of date (`04b`).

### 4.4 Board and list

- **Completion** is the round control at the start of a card or row. Completed items show a filled check and stay readable (7.55:1).
- **Selection** is shown by the accent border, the selected background and a corner check badge (cards), or a left bar (rows). It is a different control and shape from completion.
- **Non-drag moves.** **Move to** in the selection bar, and **Move… `M`** on a focused card. Move to lists workflow columns. "Mark complete (moves to Done)" is separate because it changes completion, not workflow.
- **Long titles** wrap to three lines on cards, with the full title in details and the accessible name. They are never truncated in the list or the panel.
- **Visible list metadata:** duration, the nearest date marker and the schedule state. Labels, priority and Time Map are on demand, either through the Columns menu or in details.

### 4.5 Keyboard and focus (proposed)

- Every focusable element shows a 2 px `#A9C2FF` ring with a 2 px offset.
- Calendar focus order: top bar → navigation → toolbar → schedule bar → day columns (←/→ across days, ↑/↓ through items in time order) → panel tabs → panel content.
- Single-key shortcuts work only when focus is not in a text field: `[` navigation, `\` panel, `?` key, `↵` open, `⇧P` pin/unpin, `M` move, `Esc` close the innermost layer.
- Every drag has a menu or button equivalent.
- These are static mockups. Keyboard and screen-reader behaviour are not demonstrated, only specified.

## 5. Calendar visual language

| State | Cues (none relies on colour alone) |
| --- | --- |
| External event | Calendar icon · solid fill · no border |
| Pinned placement | Pin icon · filled · thin border |
| Movable placement | No icon · outlined (1.5 px) |
| Proposed (unapplied) | Plus or arrow icon · dashed teal border |
| Moving away | Arrow icon · dotted border · muted text "Moves to …" |
| Overlap | Later item indents over the earlier one; columns are not split |
| Available (shown Time Map only) | Lighter band with a dotted left edge |
| Excluded (shown Time Map only) | Darker band with a text label naming the map |
| Short item (under 38 px) | One-line title; time and full title on selection |

## 6. Specification summary

- **Type** (IBM Plex Sans; Plex Mono for durations and keys):

  | Use | Size / line height · weight |
  | --- | --- |
  | Page title | 20/28 · 600 |
  | Section title | 16/22 · 600 |
  | Detail title | 17/23 · 600 |
  | Body and controls | 14/20 |
  | Card and row titles | 14/20 · 500 |
  | Metadata | 13/18 |
  | Calendar block | 13/17 |
  | Group label (uppercase, short labels only) | 12/16 |

- **Smallest text, measured:** 12 px appears only in the uppercase group labels, keycaps, the logo mark and the rail's Inbox count. That count is also in the item's accessible name and in the expanded navigation.
- **Spacing:** 4 · 8 · 12 · 16 · 24 · 32.
- **Radii:** 5 blocks · 6 controls · 8 cards · 10 panels.
- **Layout bands:**

  | Element | Size |
  | --- | --- |
  | Top bar | 52 |
  | Toolbar | 52 |
  | Schedule bar | 46 |
  | Hour, window 900 px tall or more | 44 px |
  | Hour, shorter windows | 36 px |
  | Minimum calendar block | 22 px |

**Measured contrast** (WCAG 2.x ratios computed from the token hex values on the background each is used on):

| Foreground → background | Ratio |
| --- | --- |
| Primary text `#E8ECF7` → surface `#10172E` | 15.01 |
| Primary text → selected `#1E2D60` / pinned fill `#22346C` | 11.11 / 10.01 |
| Secondary `#BAC3DC` → surface / pinned fill / selected | 10.07 / 6.72 / 7.46 |
| Muted `#9AA5C4` → raised `#18213F` / surface and popovers | 6.44 / 7.22 |
| Completed title `#A9B3CE` → raised | 7.55 |
| Accent `#7EA6FF` → surface; text on accent button | 7.42; 7.92 |
| Soft target `#C9B2FF` / deadline `#FFA273` / warning `#FFC07A` → raised | 8.50 / 8.03 / 9.84 |
| Proposed border `#62D3C5` → grid `#0D1428` | 10.14 |
| Movable border `#7193EE` → grid | 6.19 |
| Availability edge `#5B6FB0` → band `#141E3D` | 3.39 (raised from 2.60 during this pass) |
| Focus ring `#A9C2FF` → surface | 10.01 |

Calendar fills differ from the grid by only 1.4–1.6:1. Block identity comes from icon, border style and text, not fill. Static mockups do not establish keyboard, screen-reader or full WCAG compliance.

## 7. Scope of changes

**Visual (styling only)**
- Token set and type scale above; minimum 13 px content text.
- Quieter Time Map bands and labelled exclusions; no hatching.
- Block states distinguished by icon and border style.
- Completed items stay readable without strikethrough.
- Raw identifiers moved into a collapsed "Technical details" section.

**Interaction (behaviour of existing features)**
- One support panel with tabs; task details replace its content; collapse to a strip.
- Navigation rail with flyouts, as an alternative to the expanded tree.
- A schedule bar with explicit states. Apply and Discard replace Update schedule while a preview is open.
- A popover for the selected block. Height-based block text rules.
- Overlap cascade instead of split columns.
- Selection made visually separate from completion. Move to / Move… as non-drag paths.
- Inline unsaved-changes prompt.
- Proposed shortcut set and focus order.

**Proposed new capabilities (need product decisions; not assumed to exist)**
- A **"Preview out of date"** state, which requires knowing the preview's inputs changed.
- An **"Out of date" (stale)** state for the schedule and for per-task explanations, which requires tracking changes since the last evaluation.
- A **"Can't fit before deadline"** outcome with a reason. It requires the scheduler to report infeasibility per task.
- **"Not eligible for placement"** with the scheduler's reason.
- **Grouping adjacent short placements** into one block ("Kubernetes · 2 tasks").
- **Remembered panel and navigation state**, and the rule that windows under 1200 px start with the rail.

## 8. Unresolved functional questions

1. **Apply preview.** Does applying commit exactly the previewed placements, or re-run the scheduler? If it re-runs, the button must say so (for example "Update schedule (recomputes)"), and the preview cannot promise its result.
2. **Update schedule vs Preview.** Is Update schedule currently "evaluate and apply" with no confirmation? The design adds a confirmation step; confirm that is acceptable.
3. **Staleness.** Can the app tell that inputs changed since the last evaluation (for the schedule, a task explanation, or an open preview)? If not, these states should not ship.
4. **Infeasibility.** Does the scheduler report per-task "can't fit before deadline" outcomes, and with what reason text?
5. **Eligibility.** Which tasks are eligible for placement (workflow state, duration, Time Map, schedule style)? Is there a per-task "manual" setting? The "Not eligible" and "Not scheduled" wording depends on this.
6. **Done column.** Is Done a workflow state, or the view of completed tasks? The design treats moving to Done as marking complete.
7. **Schedule style.** What are its values? The panel shows a placeholder, "Project default".
8. **Clear unpinned.** Does it remove movable placements only, or also unapplied previews? It isn't shown in R3's schedule bar. Should it live in the bar's overflow menu?
9. **External busy events.** "Coursera learning time" is treated as external busy, per the brief, so coursework is not placed in it. Is that the intended outcome, or should coursework be placed inside it?
10. **Time Map display.** The calendar shows one selected Time Map's bands at a time. Is a "no bands" option needed for busy weeks?
11. **Short placements.** Does the engine create back-to-back very short placements (1–5 min), and is grouping them acceptable?

## 9. Illustrative content and assumptions

- **Real** (from the screenshots):
  - Kubernetes Essentials course, section and task titles, durations and labels.
  - Assessment due Oct 13.
  - Coursera learning time, AH @ Wagner, Reminder: Das Bros, Hair — Holly Mount.
  - Epics, projects, labels; Inbox 50.
- **Illustrative:**
  - The Oct 12–18 week and every time in it.
  - The open preview, its three changes and the "couldn't place" result.
  - The Unscheduled count of 6.
  - All other tasks and events (Kubernetes lab, Lab: Deploy a sample app, Renew passport photos, Insurance form, Practice lines, Write talk outline, Standup, Team offsite, Lunch with Sam, Return library books, Follow up with landlord, and others).
  - The Coursework and Errands Time Map names and bands.
  - The "Why this time" reasons; the "Import · Coursera template" source line.
- **None of this represents Trish's actual schedule.** No screen shows a schedule as applied or an AI action as taken.

## 10. Review criteria — evidence

| Question | Evidence |
| --- | --- |
| Read the busy week without the key? | `01b`/`01c`: icon and border cues, quiet bands, readable 13 px block text. The key is on demand in `01d`. |
| Does collapsing help? | `01b` vs `01c`: same content, columns widen from 115 to 160 px, and Apply/Discard stay in the bar. |
| Smaller layout resolved? | `02a`/`02b`: no toolbar wrap (toolbar measured at 52 px), no clipped rail labels, and 7 AM–10 PM fits at 36 px per hour. `01e` shows 125% zoom. |
| Long titles and metadata? | `03`: 3-line clamp on cards. `05`/`05b`: full wrap in the list. `04a`: full title in the panel. |
| Action and state meanings? | Completion vs selection (`03`, `05`); "Unschedule (keep task)" vs "Delete task…" (`04a`); preview vs apply (`04b`); constraint copy for deadlines (`04a`). |
| Keyboard? | Focus ring shown on a card (`03`) and a rail item (`02c`). Focus order and keys in §4.5. Not demonstrated in a live build. |
| Scope reviewable? | §7. |

## 11. Stopping point

This package ends the R3 pass. The next step is Trish's review: whether this direction is ready for an implementation specification, and the answers to the questions in §8.
