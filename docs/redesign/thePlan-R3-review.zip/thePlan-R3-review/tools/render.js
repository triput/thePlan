// Usage: node render.js <jobs.json>
// Builds standalone HTML from .dc.html artboards (local shim + local fonts) and screenshots them.
const fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const S = '/tmp/claude-0/-home-claude/6a1785af-87c9-52a7-96aa-571a168d69b4/scratchpad';
const SRC = path.join(S, 'canvas/project'), BUILD = path.join(S, 'export/build'), OUT = path.join(S, 'export/png');
fs.mkdirSync(BUILD, { recursive: true }); fs.mkdirSync(OUT, { recursive: true });
const FS = path.join(__dirname, 'node_modules/@fontsource');
const fonts = [['IBM Plex Sans', 'ibm-plex-sans', [400, 500, 600]], ['IBM Plex Mono', 'ibm-plex-mono', [400, 500]]];
let css = '';
for (const [fam, pkg, ws] of fonts) for (const w of ws) {
  const f = `${pkg}-latin-${w}-normal.woff2`;
  fs.copyFileSync(path.join(FS, pkg, 'files', f), path.join(BUILD, f));
  css += `@font-face{font-family:'${fam}';font-weight:${w};font-style:normal;src:url(${f}) format('woff2')}\n`;
}
fs.writeFileSync(path.join(BUILD, 'fonts.css'), css);
fs.copyFileSync(path.join(__dirname, 'shim.js'), path.join(BUILD, 'shim.js'));
fs.copyFileSync(path.join(SRC, 'r3.css'), path.join(BUILD, 'r3.css'));
const jobs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }).catch(() => chromium.launch());
  for (const j of jobs) {
    let html = fs.readFileSync(path.join(SRC, j.file), 'utf8');
    html = html.replace('<script src="./support.js"></script>', `<script>window.__PROPS=${JSON.stringify(j.props || {})}</script><script src="shim.js"></script>`)
      .replace(/<link[^>]*fonts\.googleapis\.com[^>]*>/g, '<link rel="stylesheet" href="fonts.css">');
    const b = path.join(BUILD, j.file.replace('.dc.html', '.html'));
    fs.writeFileSync(b, html);
    const ctx = await browser.newContext({ viewport: { width: j.w, height: j.h }, deviceScaleFactor: j.dpr || 1 });
    const page = await ctx.newPage();
    const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
    await page.goto('file://' + b);
    await page.waitForSelector('html[data-ready="1"]', { timeout: 10000 });
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(150);
    await page.screenshot({ path: path.join(OUT, j.out), fullPage: !!j.full });
    console.log('ok', j.out, errs.length ? 'ERR ' + errs.join(' | ') : '');
    await ctx.close();
  }
  await browser.close();
})();
