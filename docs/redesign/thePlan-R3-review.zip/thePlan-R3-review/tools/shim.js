// Minimal local renderer for the .dc.html subset used in these artboards:
// {{path}} holes, <sc-for list as>, <sc-if value>, <helmet>. For PNG export only.
(function () {
  window.DCLogic = class { constructor(p) { this.props = p || {}; this.state = {}; } setState(s) { Object.assign(this.state, s); } forceUpdate() {} };
  function resolve(path, scope) {
    path = path.trim();
    if (path === 'true') return true; if (path === 'false') return false;
    if (/^-?\d+(\.\d+)?$/.test(path)) return Number(path);
    let v = scope;
    for (const k of path.split('.')) { if (v == null) return undefined; v = v[k]; }
    return v;
  }
  const HOLE = /\{\{\s*([\w.$]+)\s*\}\}/g, WHOLE = /^\s*\{\{\s*([\w.$]+)\s*\}\}\s*$/;
  function interp(s, scope) { return s.replace(HOLE, (_, p) => { const v = resolve(p, scope); return v == null ? '' : String(v); }); }
  function render(parent, node, scope) {
    if (node.nodeType === 3) { parent.appendChild(document.createTextNode(interp(node.nodeValue, scope))); return; }
    if (node.nodeType !== 1) return;
    const tag = node.localName;
    if (tag === 'sc-for') {
      const list = resolve(node.getAttribute('list').replace(/[{}]/g, ''), scope) || [];
      const as = node.getAttribute('as') || 'item';
      list.forEach((it, i) => { const s = Object.create(scope); s[as] = it; s.$index = i; node.childNodes.forEach(c => render(parent, c, s)); });
      return;
    }
    if (tag === 'sc-if') {
      if (resolve(node.getAttribute('value').replace(/[{}]/g, ''), scope)) node.childNodes.forEach(c => render(parent, c, scope));
      return;
    }
    const el = node.cloneNode(false);
    for (const a of Array.from(node.attributes)) {
      if (a.name.startsWith('hint-') || /^on[a-z]/i.test(a.name)) { el.removeAttribute(a.name); continue; }
      const m = a.value.match(WHOLE);
      if (m) {
        const v = resolve(m[1], scope);
        if (v === false || v == null || typeof v === 'function') el.removeAttribute(a.name);
        else el.setAttribute(a.name, v === true ? '' : String(v));
      } else if (a.value.includes('{{')) el.setAttribute(a.name, interp(a.value, scope));
    }
    const src = node.localName === 'template' ? node.content : node;
    src.childNodes.forEach(c => render(el, c, scope));
    parent.appendChild(el);
  }
  document.addEventListener('DOMContentLoaded', () => {
    const sc = document.querySelector('script[data-dc-script]');
    const defs = JSON.parse(sc.getAttribute('data-props') || '{}');
    const props = {};
    for (const k in defs) if (defs[k] && typeof defs[k] === 'object' && 'default' in defs[k]) props[k] = defs[k].default;
    Object.assign(props, window.__PROPS || {});
    const Component = new Function('DCLogic', sc.textContent + '\n;return Component;')(window.DCLogic);
    const c = new Component(props); c.props = props;
    const vals = c.renderVals();
    const x = document.querySelector('x-dc');
    const helmet = x.querySelector('helmet');
    if (helmet) { Array.from(helmet.childNodes).forEach(n => document.head.appendChild(n)); helmet.remove(); }
    const frag = document.createDocumentFragment();
    x.childNodes.forEach(n => render(frag, n, vals));
    x.replaceWith(frag);
    document.documentElement.setAttribute('data-ready', '1');
  });
})();
