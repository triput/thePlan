import sys
def lum(h):
    h=h.lstrip('#'); r,g,b=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    f=lambda c: c/12.92 if c<=0.03928 else ((c+0.055)/1.055)**2.4
    return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b)
def cr(a,b):
    la,lb=lum(a),lum(b); hi,lo=max(la,lb),min(la,lb); return (hi+0.05)/(lo+0.05)
T=dict(bg='#0B1020',surface='#10172E',grid='#0D1428',avail='#141E3D',excl='#0A0F1E',raised='#18213F',sel='#1E2D60',
 ext='#232D4E',pin='#22346C',move='#111A36',prop='#0E2630',warnbg='#2A2115',
 ink='#E8ECF7',ink2='#BAC3DC',ink3='#9AA5C4',done='#A9B3CE',accent='#7EA6FF',onacc='#0B1020',
 target='#C9B2FF',deadline='#FFA273',teal='#62D3C5',warn='#FFC07A',ok='#86D9AE',line='#2A3560',lineSoft='#1B2446',moveEdge='#7193EE')
pairs=[l.split() for l in """ink bg
ink surface
ink raised
ink sel
ink ext
ink pin
ink move
ink prop
ink2 surface
ink2 raised
ink2 ext
ink2 pin
ink2 move
ink2 avail
ink2 sel
ink3 surface
ink3 raised
ink3 grid
ink3 avail
ink3 excl
done raised
done surface
accent surface
accent raised
onacc accent
target raised
target surface
deadline raised
deadline surface
teal prop
teal surface
warn warnbg
ink warnbg
ok surface
moveEdge grid
moveEdge avail
teal grid
line surface
avail grid
excl grid""".strip().splitlines()]
for a,b in pairs:
    print(f"{a:9s} {T[a]} on {b:8s} {T[b]}  {cr(T[a],T[b]):5.2f}")
