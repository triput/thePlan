# Editable source for R3

- `source/*.dc.html` and `source/r3.css` are the artboards on the "thePlan Design Directions" canvas, on the page "R3 · Midnight Workbench refinement". Edit them on the canvas, or edit the files directly. Each artboard is plain HTML plus a small `renderVals()` data block; `r3.css` holds every token and component style.
- `tools/` contains what produced the PNG exports:
  - `shim.js` is a minimal local renderer for the artboard format.
  - `render.js` builds standalone HTML with local IBM Plex fonts and screenshots it with Playwright: `node render.js final.json`.
  - `contrast.py` computes the WCAG ratios quoted in the review.
- These are design files, not production components.
