# thePlan redesign — round 2 decisions

Follows `01-design-exploration-round-1.md`. Direction A (Workbench) continues as the base; new artboards are the "A Dark" row on the canvas.

## Decisions from Trish (Oct 10, 2026)

1. **Dark mode is required.** Solarized dark or a rich midnight blue are both acceptable. Two token sets were built: Midnight (default) and Solarized, switchable per artboard in Tweaks.
2. **Labels are for filtering, not navigation.** Labels leave the sidebar. They live in a filter popover (Any / All / None of), in the ⌘K palette, and on a "Manage labels" page under Library.
3. **Heavy weeks are busy and bursty.** Daytime work events mix with personal ones; evenings hold education, theater and other personal events. The calendar has to stay readable at that density.
4. **Shortcuts are open to redesign.** The proposed map below is a starting point.
5. **Pinned vs. movable:** Pinned items are placed by Trish or come from an external calendar; the scheduler never moves them. Everything else (events and tasks) may be moved by the scheduler or AI.

## How round 2 applies these

- **Pinned** = filled block + pin icon + the word "pinned". **Movable** = outlined block + drag grip. Never color alone.
- "Clear unpinned" is relabeled **"Clear unpinned placements…"**, since it clears only movable placements.
- Task detail has a **"Pin this time"** switch with the rule stated next to it, plus "Why this slot" and an activity log showing which moves the scheduler made, each with Undo.
- The busy-week calendar adds:
  - A schedule-freshness banner ("Out of date — 3 tasks edited since last run").
  - A per-day load figure.
  - Due, target and deadline markers in the day header.
  - Side-by-side layout for overlaps, plus a **Needs attention** panel for overlaps and unplaceable deadlines.
  - A "Moved by scheduler" list with Undo.
- All busy-week content, placements, reasons and activity entries are mock and labeled as such on the canvas.

## Proposed shortcut map (draft)

| Area | Keys |
|---|---|
| Global | ⌘K command/search/add · N new task · / search · ? shortcut sheet · G then I/T/U/C/B go to Inbox/Today/Upcoming/Calendar/Board · G then D go to date |
| Filters | F add filter · L quick label filter · ⇧L clear labels · S save current view |
| Selection | J/K next/previous · X complete · Space extend selection · ⇧-click range · Esc clear |
| Board | ←/→ move between columns · M move to… · ↵ open details · E edit title inline |
| Outline | Tab/⇧Tab indent/outdent · ⌥↑/⌥↓ reorder · ←/→ collapse/expand · O new sibling |
| Calendar | [ / ] previous/next week · T today · W toggle work-hours zoom · P preview schedule · U undo last scheduler move |
| Task detail | ⌘↵ save · Esc close · ⇧P pin/unpin · D due · T soft target · ⇧D deadline · ⌫ unschedule |

## Still open

- Exact epic colors for dark themes.
- Whether "work hours" zoom should be the default on weekdays.
- How overlaps between two pinned items should appear, given that the scheduler can't resolve them.
