# thePlan design review package — Oct 10, 2026

Contents
1. `01-design-exploration-round-1.md` — assessment of the current UI, three directions (A Workbench, B Night Shift, C Life Lanes), comparison, recommendation, open questions.
2. `02-design-decisions-round-2.md` — your answers (dark mode, labels as filters, busy weeks, shortcuts, pinned vs movable), how the dark Workbench row applies them, and a draft shortcut map.

Mockups
The 20 mockup screens live on the "thePlan Design Directions" canvas, in four rows:
- A · Workbench (light)
- B · Night Shift
- C · Life Lanes
- A Dark: Midnight and Solarized calendars, a busy week, the board with the label filter, and task detail with pinning

To download the visuals, open the canvas and use Share › Export (PDF or images).

Labeling: dashed "Proposed" blocks, the busy-week contents, scheduler reasons and activity entries are illustrative. Tasks, labels, durations, dates and calendar events otherwise come from the original screenshots. No application code was changed.
