# thePlan UI design exploration — round 1

Companion to the "thePlan Design Directions" canvas (15 artboards: 3 directions × weekly calendar, Kanban, hierarchical list, task detail, Import). All artboards are finished concept screens at 1440×900 using the same real content from the screenshots. Illustrative content is labeled on the canvas: dashed "Proposed" calendar blocks, the Review/Apply steps of Import, shortcuts not already in the app, and (Direction C only) which epic each calendar event belongs to.

No application code was changed.

---

## 1. Assessment of the current UI

**Supported by the screenshots**

1. **Nothing leads the eye.** Every surface is a slightly different near-black; the one strong signal is the green primary button, used for Save, Board, Update Schedule, Week and Propose preview alike. Five unrelated things share one "most important" color.
2. **The sidebar is carrying the whole taxonomy.** Views, saved views, ~22 labels, epics and projects all live in one scrolling column. Labels alone push Epics and Projects below the fold, even though epics are the user's actual life areas.
3. **Time-map windows look like events.** "Coursera learning time" renders the same as "AH @ Wagner". You can't tell available time from booked time — the most important distinction in a scheduler.
4. **Scheduling state is implicit.** "Update Schedule" sits beside "Preview changes" and "Clear unpinned" with no indication of when the schedule last ran. The detail panel does say "No scheduling evaluation recorded" — good honesty, but it's only visible per task.
5. **Card chrome outweighs card content.** Each Kanban card carries a truncated parent path (the same course name 50 times while already filtered to it) and a full-width "Move to…" select. The useful bits — duration, label — are the smallest text on the card.
6. **Two identical checkboxes per list row.** One is selection, one is completion; they look the same.
7. **Dates are three identical inputs.** Due, Soft target and Deadline are visually the same field; the helper text is the only differentiator.
8. **Detail panel is long and flat.** Machine metadata ("outline_id: m01-t05") is shown as the description; scheduling fields are below the fold; there are two Save buttons.
9. **Dense forms aren't structured.** Import presents 12+ controls with no step order or required/optional distinction. The saved-view builder uses a 2-column checkbox grid where long project names wrap to 4 lines.
10. **Header shows the internals.** "Year 2026: Week 41 • Days 277–283" is precise but competes with the date range.

**Needs interaction with the app to confirm**

- Keyboard coverage beyond Q and / (the screenshots show those hints only).
- What "Schedule style" options are, and what "Clear unpinned" removes.
- Whether "Coursera learning time" is a time-map window or a recurring task/event (I've treated it as a window).
- Focus visibility, screen-reader labeling, and whether the Kanban supports keyboard moves.
- How busy a typical week gets — the screenshot week is sparse.

---

## 2. Three directions

### A · Workbench — light, precise, keyboard-first

**Experience:** A tool that feels like a good IDE: quiet, ordered, fast. Light ground, IBM Plex Sans with Plex Mono for every number, duration and date. Three panes: slim nav, main view, always-docked inspector, plus a status bar that shows schedule/time-map state and keyboard hints.

**Why:** Built for the user's stated priorities — efficient entry, keyboard use, CLI/AI workflows, and real information density without crowding. Monospaced metadata makes durations and dates scannable down a column.

**Key moves:**
- One command field (⌘K) replaces separate Quick add and Search.
- Labels leave the sidebar (they become filter chips and a Library page); Epics move up.
- A schedule-state banner ("Schedule not evaluated…") sits above the calendar and frames the three schedule actions.
- Time-map windows are hatched; events are filled; proposals are dashed.
- Kanban cards drop the repeated parent path and the Move select; moves are drag, ←/→, or M.
- List has one checkbox (complete); selection is a row state with a bulk-action bar.
- Detail is a docked inspector, not a stacked form: Dates group with distinct glyphs (● due, ◇ soft target, ▲ deadline), a placement card, one Save with unsaved-change indicator.
- Import becomes a 3-step page (Configure → Review proposal → Apply/receipt) with a live structure preview beside the form.

**Tradeoffs:** The docked inspector costs ~320px of width; on smaller laptops the board shows fewer columns. Light theme is a departure from the current app. Its strength (dense, mono metadata) can tip into "spreadsheet" if every field is shown.

**Needs interaction redesign, not styling:** command palette; keyboard card moves; row selection model; inspector replacing the side panel; Import as a stepped flow.

### B · Night Shift — dark, calm, one thing at a time

**Experience:** The current dark theme matured: deeper ink ground, one desaturated teal accent, Schibsted Grotesk at larger sizes, JetBrains Mono for times. Generous spacing. The interface shows one view at a time and lets detail slide in over it.

**Why:** Keeps the familiar dark mode and its evening-friendly comfort while removing noise. Best when the user wants to focus — review the week, work a board — rather than administer.

**Key moves:**
- No permanent sidebar: a scope chip ("Inbox · Education ▾") holds the taxonomy; a pill switcher holds Today / Week / Board / Outline.
- A plan-state card above the calendar states whether the schedule has been evaluated, in plain language.
- Unplaced tasks live in a collapsible edge tray (U) instead of competing with the grid.
- Board cards are title + one meta line; actions appear on hover/focus (Start, Move, Open).
- Outline reads like a document: section TOC on the left, readable column, round complete toggles.
- Detail is a drawer with tabs (Plan / Scheduling / Notes / History) and three "add" buttons that explain each date type before you set one.
- Import is a vertical step accordion with optional fields collapsed under one disclosure.

**Tradeoffs:** Hiding the sidebar makes epics and saved views one click further away. Spacious cards show fewer tasks per screen — the Ready column of 50 needs more scrolling. Hover-revealed actions are less discoverable (mitigated by keyboard and focus reveal). Drawer covers the board while editing.

**Needs interaction redesign:** scope chip navigation; edge tray; hover/focus card actions; tabbed drawer; accordion Import.

### C · Life Lanes — bright, organized by life area

**Experience:** High-contrast white with bold Bricolage Grotesque headings and Atkinson Hyperlegible body text. Epics (Theater, Home, Career, Travel, Education) become the primary organizing axis, each with a color *and* a letter badge so meaning never depends on color.

**Why:** The user's life spans distinct domains. Seeing "how much of my week is Theater vs. Education" at a glance is something neither the current UI nor A/B surfaces directly. Large type and chunky controls are approachable and very readable.

**Key moves:**
- Lane chips under the top nav filter every view by epic.
- Calendar blocks carry their epic badge; a "Time by lane" panel totals booked time and available windows.
- Board becomes swimlanes: one row per epic × status columns; filtered-out lanes collapse to a one-line row.
- Outline groups Epic → Project → Section in bordered cards with progress.
- Detail is a split page: Ready column stays visible on the left; three date cards with distinct borders (solid, dashed, heavy red).
- Import is a choose-then-review wizard with template cards and a dark summary panel that states nothing is added until Apply.

**Tradeoffs:** Depends on every task belonging to an epic — inbox and unassigned work need a home. Five epic colors plus status plus labels can get loud in a busy week. Swimlanes need horizontal room and hide WIP across lanes unless totaled. Lowest density of the three.

**Needs interaction redesign:** epic as a global filter; swimlane board; per-epic time totals (requires epic on events, which I assumed); split-page detail.

---

## 3. Comparison

| | A · Workbench | B · Night Shift | C · Life Lanes |
|---|---|---|---|
| Density | High, structured | Medium-low | Low |
| Keyboard emphasis | Strongest (palette, status bar, visible keys) | Good (shortcuts on actions) | Basic |
| Navigation | Slim sidebar + ⌘K | Scope chip + view pill | Top tabs + lane chips |
| Detail editing | Docked inspector | Overlay drawer with tabs | Split page |
| Schedule honesty | Banner + status bar + legend | Plan-state card | Schedule panel + legend |
| Busy-view resilience | Best | Moderate (scrolling) | Moderate (color load) |
| Sparse-view feel | Fine, slightly empty | Calm | Friendly, inviting |
| Distance from today | Big (light, 3-pane) | Smallest | Big (new organizing axis) |
| Main risk | Feels clinical | Hides structure | Over-reliance on epics |

---

## 4. Recommendation

**Direction A (Workbench) as the base, with two borrowings.**

- It matches the profile in the brief most directly: an experienced technical user who values keyboard entry, CLI/AI workflows and understandable density. The docked inspector keeps the board visible while editing, which B's drawer and C's split don't fully do.
- It handles the busy case best, and the busy case (50-task Ready column, full weeks) is where the current UI struggles most.
- Its scheduling treatment is the most explicit about state: banner, status bar and legend together make it hard to mistake a preview for an applied schedule.

Borrow from B: a dark variant of A's tokens (the current user likely values dark mode), and B's plain-language plan-state copy. Borrow from C: lane chips as an optional filter and the "Time by lane" summary — both are additive and don't require restructuring around epics.

If the user would rather keep the app feeling like it does today, B is the lowest-risk path and still fixes most of the assessment items.

---

## 5. Questions to refine the selected direction

1. Is dark mode a must, a preference, or neutral? (Decides whether A ships light-first or dark-first.)
2. Is "Coursera learning time" a time-map window or a scheduled block? Are "AH @ Wagner" calls rehearsals (Theater)?
3. How often do you use labels as navigation vs. as filters? Can they leave the sidebar?
4. What does a heavy week look like — how many fixed events and placed tasks?
5. Which keyboard shortcuts exist today, and would a ⌘K command palette replace or complement the CLI?
6. What does "Clear unpinned" remove, and how often do you run Update Schedule?
7. Should every task belong to an epic, or is a large unassigned inbox normal?
8. What are the "Schedule style" options, and which do you actually change?
